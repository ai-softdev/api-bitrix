from bitrix24 import *
import bitrix24

#bx24 = Bitrix24('https://b24-k8czgy.bitrix24.kz/rest/1/8eo8rkqfmtjbwj1q/')
bx24 = Bitrix24('https://b24-x0q441.bitrix24.ru/rest/1/unlgtq27bj9oy1nb/')
# bx24.callMethod('tasks.task.list', filter={"PARENT_ID":"0"})
# print(res)
# res = bx24.callMethod('tasks.task.get',taskId=1 )
# print(res)
# print(res)
# print(len(res.get('tasks')))


