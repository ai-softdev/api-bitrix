# from enum import Enum
#
# currency_enum = ('UZS', 'USD')
# units_enum = ('кг', 'шт')
#
#
# class UnitsEnum(Enum):
#     KG = 'кг'
#     UNITS = 'шт'
#
#
# class CurrencyEnum(Enum):
#     UZS = 'UZS'
#     USD = 'USD'
    # RUB = 'RUB'
